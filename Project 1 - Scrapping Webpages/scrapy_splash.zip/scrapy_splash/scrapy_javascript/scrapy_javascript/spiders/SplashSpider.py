from scrapy.spiders import Spider
from scrapy_splash import SplashRequest
from ..items import GameItem

class MySpider(Spider):
	name = 'splash_spider' # Name of Spider
       # user_agent = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'
	start_urls = ['https://www.whatsmyua.info']
#        start_urls = ['https://www.whatismybrowser.com/detect/ip-address-location'] # url(s)
#        start_urls = ['http://www.starcitygames.com/catalog/magic_the_gathering/'] # url(s)

        def start_requests(self):
		for url in self.start_urls:
			yield SplashRequest(url=url, callback=self.parse, args={"wait": 3})
               # for url, GameItem in urls:
                #    yield scrapy.Request(url, meta={'GameItem': GameItem})

	#Scraping
	def parse(self, response):
		item = GameItem()
                #for game in response.css("div.content"):
                    # Card Name
                    #item["IP_Address"] = game.css("strong::text").extract_first() 
 		    # Price
		    #item["Price"] = game.css("td.deckdbbody.search_results_9::text").extract_first()
                for game in response.css("div.top.block"):
                    item["user_agent"] = game.css("textarea#custom-ua-string.input::text").extract_first()
                    yield item
